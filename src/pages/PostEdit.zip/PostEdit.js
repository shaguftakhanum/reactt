import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from 'axios';
import Layout from "../components/Layout/Layout";
import 'bootstrap/dist/css/bootstrap.css';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
const PostEdit = () => {
    const params = useParams();
    console.log('params =>', params);
    const [name, setName] = useState('')
    const [blogId, setBlogId] = useState();
    const [images, setImages] = useState([])
    const[item,setitem]=useState([]);
    let blog_id = 0;
     useEffect(() => {
        axios({
            method: 'get',
            url: 'http://localhost:8000/api/post/' + params.id,
        })
            .then(({ data }) => {
                const files = data.data.files.map((file) => file.name);
                console.log('post data =>', data.data.posts.blog_id);
                setName(data.data.posts.name);
                // setBlogId(data.data.posts.blog_id);
                blog_id = data.data.posts.blog_id;
                console.log("blog Id ===> ", blog_id);
                setImages(files);
            }).then(res=>{
                axios.get(`http://localhost:8000/api/blogs/getall`)
            .then(res => {
                // console.log('res =>',res);
                console.log('data =>',res.data.data)
                setitem(res.data.data);
            })
            })
            .catch(function (error) {
                console.log("error=>", error);
            });

    },
    []);
    const handlenamechange = (e) => {
        // console.log(e.target.value)
        setName(e.target.value);
    }
    const fileChangedHandler = (e) => {
        const updatedImages = [...images, e.event.target[0]];
        setImages(updatedImages);
    }
    const handleclick=(e)=>{
        console.log("e ===> ", e);
        axios({
            method: 'put',
            url: 'http://localhost:8000/api/post/' + params.id,
            data: {
                name: name,
                files: images
            }
        })
            .then((res) => {
                console.log("res=>", res);


            })
            .catch(function (error) {
                console.log("error=>", error);
            });


    }


  return (
    <>
    <Layout>
        <br/>
<form>
    <label>Name</label>
    <input type="text" value={name} name="name"   onChange={(e)=>handlenamechange(e)} /><br/>
    <label>selected Blog</label><br/>
    <select value={blog_id}><br/><br/>
    {
        item.map((items) => (
            <option key={items.id} value={items.id}>{items.name}</option>
        ))
    }
    </select>
    <br/><br/>
    < input  type="file"  onChange={(e)=>fileChangedHandler(e)} ></input>
    <br/><br/>
    <Button onClick={(e) => handleclick(e)} type="button" className="btn">update</Button>
</form>
    </Layout>
    </>
  )
}

export default PostEdit